function instrucoes
  msgbox("Conven��es usadas:\n\n\t\t* Direita --> positiva\n\t\t* Cima --> positiva\n\t\t* Anti-Hor�rio --> positivo");
endfunction
