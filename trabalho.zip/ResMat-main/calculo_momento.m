function momento = calculo_momento(matriz_forca_pos)
  momento = matriz_forca_pos[:,1].* matriz_forca_pos[:,2];
endfunction
