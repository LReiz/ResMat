function angulo_em_rad = grau_para_rad(angulo_em_grau)
  angulo_em_rad = angulo_em_grau .* (pi/180);
endfunction
