function [opcao] = opcaoApoios()
     opcao = menu("Qual ser� o tipo de problema?", 
          "1 Apoio Engastado", 
          "1 Apoio Pino e 1 Apoio Rolete",
          "2 Apoios Roletes");
endfunction
